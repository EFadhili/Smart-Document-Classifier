package org.example;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Test UI");
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JButton b = new JButton("Hello");
            f.add(b);
            f.setSize(300, 200);
            f.setLocationRelativeTo(null);
            f.setVisible(true);
        });
    }
}
